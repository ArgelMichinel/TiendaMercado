<?php

$pdo = new PDO('mysql:host=database-1.cnxbwilgrgwt.us-east-1.rds.amazonaws.com;dbname=id21371385_mercadofree2;charset=utf8', 'root', 'odfknoiesdfkl42');

$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);