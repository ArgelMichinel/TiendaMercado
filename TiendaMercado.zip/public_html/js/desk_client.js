
/*function query_packets() {
    let activar = document.getElementById('screem-packets');
    let desactivar = document.getElementById('principal');

    
    document.getElementById('presentacion').style.background = "none";
    desactivar.style.display = "none";
    activar.style.display = "block";
    
    if (document.getElementById("envios").value == '-1') {
        document.getElementById('id01').style.display = "flex";
    }
}*/

function assing_credential() {
    window.location.href = "https://www.pegasoenvios.com/curl.php"
}

function query_packets() {
    window.location.href = "https://www.pegasoenvios.com/query_client.php"
}
