
////////////////////////////// 
document.addEventListener('DOMContentLoaded',function(){  
    if (document.getElementById("errores").value != 0) {
        document.getElementById('id01').style.display = "block";
    }
});
