<header>
    <nav class="navbar navbar-expand-lg">
        <div class="container p-4"><a href="#" class="navbar-brand fw-bold"><img src="./img2/mercadofree-logo.png"
                    alt="logo"> Mercado Free</a><button type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="true"
                aria-label="Toggle navigation" class="navbar-toggler"><span
                    class="navbar-toggler-icon"></span></button>
            <div id="navbarSupportedContent" class=" navbar-collapse collapse" style="">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a aria-current="page" class="nav-link active" href="">Ofertas</a></li>
                    <li class="nav-item"><a class="nav-link" href="">Especiales</a></li>
                </ul>
                <li class="d-flex"><a class="nav-link" href="./registrar.php">Creá tu cuenta</a><a class="nav-link" href="./login.php">Ingresar</a></li>
                <form role="search" class="d-flex" style="width: 270px;"><input type="search" placeholder="Search"
                        aria-label="Search" class="form-control me-2"><button type="submit"
                        class="btn btn-outline-success">Search</button></form>
            </div>
        </div>
    </nav>
</header>